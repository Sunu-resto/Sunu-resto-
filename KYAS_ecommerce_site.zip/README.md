# K.Y.A.S — Site e-commerce

Site vitrine + panier e-commerce responsive pour K.Y.A.S Cafétéria & Restauration.

## Contenu
- `index.html` : page principale
- `style.css` : design responsive noir/or
- `app.js` : produits, panier et commande WhatsApp
- `assets/logo.png` : logo fourni
- `assets/affiche.jpg` : affiche fournie

## À modifier avant mise en ligne
1. Dans `app.js`, renseigner `WHATSAPP_NUMBER` avec le numéro WhatsApp de K.Y.A.S au format international, sans `+` ni espaces.
2. Remplacer les prix d'exemple et les produits par la vraie carte.
3. Pour un paiement en ligne, connecter ensuite le moyen de paiement choisi.
