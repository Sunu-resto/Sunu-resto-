// CONFIGURATION : remplace cette valeur par ton numéro WhatsApp au format international, sans + ni espaces.
// Exemple Sénégal : 2217XXXXXXXX
const WHATSAPP_NUMBER = "";

const products = [
  {id:1,name:"Café K.Y.A.S",cat:"Cafés & Thés",price:1500,icon:"☕",desc:"Café chaud, préparé à la commande."},
  {id:2,name:"Thé gourmand",cat:"Cafés & Thés",price:1200,icon:"🍵",desc:"Thé parfumé pour une pause douce."},
  {id:3,name:"Plat signature",cat:"Plats",price:4500,icon:"🍛",desc:"Plat généreux inspiré des saveurs locales."},
  {id:4,name:"Poulet & accompagnement",cat:"Plats",price:5000,icon:"🍗",desc:"Poulet savoureux avec accompagnement."},
  {id:5,name:"Croissant frais",cat:"Pâtisseries",price:1000,icon:"🥐",desc:"Pâtisserie fraîche du jour."},
  {id:6,name:"Pâtisserie K.Y.A.S",cat:"Pâtisseries",price:1500,icon:"🍰",desc:"Une douceur pour accompagner votre café."},
  {id:7,name:"Jus naturel",cat:"Jus",price:2000,icon:"🥤",desc:"Jus de fruits frais et rafraîchissant."},
  {id:8,name:"Jus exotique",cat:"Jus",price:2500,icon:"🧃",desc:"Mélange fruité plein de fraîcheur."}
];

let cart = JSON.parse(localStorage.getItem("kyas_cart") || "[]");

const money = n => new Intl.NumberFormat("fr-FR").format(n) + " FCFA";
function save(){localStorage.setItem("kyas_cart",JSON.stringify(cart)); renderCart();}

function renderProducts(cat="Tous"){
  const list = cat==="Tous" ? products : products.filter(p=>p.cat===cat);
  document.querySelector("#products").innerHTML = list.map(p=>`
    <article class="product">
      <div class="product-img">${p.icon}</div>
      <div class="product-body">
        <h3>${p.name}</h3><p>${p.desc}</p>
        <div class="row"><span class="price">${money(p.price)}</span><button class="add" onclick="addToCart(${p.id})">+ Ajouter</button></div>
      </div>
    </article>`).join("");
}

function addToCart(id){
  const found=cart.find(x=>x.id===id);
  if(found) found.qty++; else cart.push({id,qty:1});
  save();
}
function changeQty(id,delta){
  const item=cart.find(x=>x.id===id); if(!item)return;
  item.qty+=delta; if(item.qty<=0) cart=cart.filter(x=>x.id!==id); save();
}
function removeItem(id){cart=cart.filter(x=>x.id!==id);save();}

function renderCart(){
  const count=cart.reduce((s,x)=>s+x.qty,0);
  document.querySelector("#cartCount").textContent=count;
  const items=document.querySelector("#cartItems");
  if(!cart.length){items.innerHTML='<p style="color:#999;text-align:center;padding:30px 0">Votre panier est vide.</p>';document.querySelector("#cartTotal").textContent=money(0);return;}
  let total=0;
  items.innerHTML=cart.map(x=>{
    const p=products.find(y=>y.id===x.id); const line=p.price*x.qty; total+=line;
    return `<div class="cart-line"><div><b>${p.name}</b><br><span style="color:#999">${money(p.price)}</span></div><div class="qty"><button onclick="changeQty(${p.id},-1)">−</button><b>${x.qty}</b><button onclick="changeQty(${p.id},1)">+</button></div><button class="remove" onclick="removeItem(${p.id})">Supprimer</button></div>`;
  }).join("");
  document.querySelector("#cartTotal").textContent=money(total);
}

function openCart(){document.querySelector("#cartModal").classList.add("open");document.querySelector("#cartModal").setAttribute("aria-hidden","false");}
function closeCart(){document.querySelector("#cartModal").classList.remove("open");document.querySelector("#cartModal").setAttribute("aria-hidden","true");}

function orderWhatsApp(){
  if(!cart.length){alert("Votre panier est vide.");return;}
  if(!WHATSAPP_NUMBER){alert("Ajoutez d’abord votre numéro WhatsApp dans app.js (variable WHATSAPP_NUMBER).");return;}
  let total=0, msg="Bonjour K.Y.A.S Cafétéria 👋%0A%0AJe souhaite commander :%0A";
  cart.forEach(x=>{const p=products.find(y=>y.id===x.id);total+=p.price*x.qty;msg+=`• ${p.name} x${x.qty} — ${money(p.price*x.qty)}%0A`;});
  msg+=`%0A*Total : ${money(total)}*%0A%0AMerci de confirmer ma commande.`;
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`,"_blank");
}

document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));btn.classList.add("active");renderProducts(btn.dataset.cat);
}));
document.querySelector("#openCart").onclick=openCart;
document.querySelector("#closeCart").onclick=closeCart;
document.querySelector("#heroOrder").onclick=openCart;
document.querySelector("#whatsappOrder").onclick=orderWhatsApp;
document.querySelector("#cartModal").addEventListener("click",e=>{if(e.target.id==="cartModal")closeCart();});
document.querySelector("#year").textContent=new Date().getFullYear();
renderProducts();renderCart();
